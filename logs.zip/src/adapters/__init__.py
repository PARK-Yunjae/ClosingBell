# Adapters 모듈 - 외부 시스템 연동
