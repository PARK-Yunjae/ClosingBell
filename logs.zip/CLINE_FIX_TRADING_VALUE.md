# Cline 프롬프트 - 거래대금 조회 문제 해결

## 🔴 문제 상황
거래대금 300억 이상 종목이 **16개만** 조회됨.
한국투자증권 HTS/MTS에서는 **200개 이상** 확인됨.

---

## 🔍 예상 원인

### 원인 1: API 응답 개수 제한 (가장 유력)
한투 API `volume-rank`는 기본적으로 **30개만** 반환할 수 있음.
→ 페이징 처리 또는 다른 API 사용 필요

### 원인 2: 거래대금 단위 오류
- API 응답: `acml_tr_pbmn` (누적 거래대금)
- 현재 코드: `/ 100_000_000` (억원 변환)
- 실제 단위가 다를 수 있음 (원 vs 천원 vs 백만원)

### 원인 3: 시장 구분 코드
- 현재: `FID_COND_MRKT_DIV_CODE: "J"` (전체)
- KOSPI만 또는 KOSDAQ만 조회될 수 있음

### 원인 4: 장 마감 후 데이터
- 장 마감 후 API 응답이 제한될 수 있음

---

## 🚀 Step 1: 디버깅 - API 원본 응답 확인

```
kis_client.py의 get_top_trading_value_stocks 메서드에서
API 원본 응답을 출력하는 디버깅 코드를 추가해줘.

1. API가 몇 개의 종목을 반환하는지 확인
2. 각 종목의 거래대금 원본값(acml_tr_pbmn) 출력
3. 단위 확인 (억원인지, 원인지)

디버깅 실행:
python -c "
from src.adapters.kis_client import get_kis_client
client = get_kis_client()

# 원본 응답 확인
import requests
endpoint = '/uapi/domestic-stock/v1/quotations/volume-rank'
# ... API 호출 후 output 전체 출력
"
```

---

## 🚀 Step 2: 거래대금 순위 API 대신 다른 방법 사용

한투 API에서 거래대금 상위 종목을 제대로 가져오려면 **여러 번 호출**하거나 **다른 API**를 사용해야 할 수 있습니다.

```
거래대금 조회 로직을 수정해줘.

방법 A: 거래대금 순위 API 페이징
- volume-rank API가 페이징을 지원하는지 확인
- 지원한다면 여러 페이지 조회

방법 B: 전 종목 조회 후 필터링
- 한투 API의 '업종별 전종목' 조회 API 사용
- KOSPI 전종목 + KOSDAQ 전종목 조회
- 각 종목의 현재가에서 거래대금 확인
- 300억 이상 필터링

방법 B가 더 확실함. 구현해줘.

API 정보:
- KOSPI 전종목: /uapi/domestic-stock/v1/quotations/inquire-daily-indexchartprice
- 또는 업종별 종목 리스트 조회 API 확인 필요
```

---

## 🚀 Step 3: 실제 해결 방법 (권장)

```
거래대금 상위 종목 조회 로직을 다음과 같이 수정해줘:

1. 한투 API로 KOSPI/KOSDAQ 거래량 상위 종목 조회
   - volume-rank API로 최대한 많이 조회 (KOSPI + KOSDAQ 별도 호출)
   
2. 각 시장별로 호출:
   - KOSPI: FID_COND_MRKT_DIV_CODE = "J" → "1" 로 변경
   - KOSDAQ: FID_COND_MRKT_DIV_CODE = "2"
   - 두 결과 합치기

3. 거래대금 단위 확인:
   - acml_tr_pbmn 값이 어떤 단위인지 로그로 출력
   - 삼성전자 같은 대형주의 거래대금으로 단위 역산

수정된 코드로 테스트 실행해줘.
```

---

## 🚀 Step 4: 거래대금 단위 확인 스크립트

```
거래대금 단위를 확인하는 스크립트를 만들어줘.
scripts/debug_trading_value.py

내용:
1. 삼성전자(005930) 현재가 조회
2. acml_tr_pbmn 원본값 출력
3. 실제 거래대금과 비교해서 단위 역산
   - 오늘 삼성전자 거래대금이 약 5,000억 ~ 1조 정도
   - API 값이 50000000000000 이면 원 단위
   - API 값이 5000000000000 이면 원 단위 (조 단위)
   - API 값이 5000 이면 억 단위

python scripts/debug_trading_value.py
```

---

## 📋 Cline에 바로 입력할 종합 프롬프트

```
거래대금 300억 이상 종목이 16개밖에 안 나와.
한국투자증권 HTS에서는 200개 이상인데 뭔가 문제가 있어.

다음을 확인하고 수정해줘:

1. kis_client.py의 get_top_trading_value_stocks에서 API 원본 응답 확인
   - output 배열의 총 개수
   - 첫 번째 종목의 acml_tr_pbmn 원본값

2. 거래대금 단위 확인
   - 삼성전자(005930)의 거래대금으로 단위 역산
   - 원 단위인지, 억원 단위인지

3. KOSPI, KOSDAQ 별도 호출로 수정
   - 현재: FID_COND_MRKT_DIV_CODE = "J" (전체)
   - 수정: "1" (KOSPI) + "2" (KOSDAQ) 별도 호출 후 합치기

4. API 응답 개수 제한 확인
   - volume-rank API가 최대 몇 개 반환하는지

디버깅 후 문제를 수정하고 다시 테스트해줘.
```

---

## 💡 참고: 한투 API 거래대금 단위

한투 API 문서에 따르면:
- `acml_tr_pbmn`: **누적 거래대금** (단위: **원**)
- 삼성전자 하루 거래대금이 약 5,000억 ~ 1조원
- API 응답값이 `500000000000` ~ `1000000000000` 이면 **원 단위**

현재 코드:
```python
trading_value = float(item.get("acml_tr_pbmn", 0)) / 100_000_000  # 억원 변환
```

이게 맞다면 300억 = `30000000000` 원이므로 필터 통과해야 함.

**문제는 API가 30개만 반환하는 것일 가능성 높음!**

---

## 🔧 예상 수정 코드

```python
def get_top_trading_value_stocks(self, min_trading_value: float = 300, limit: int = 200):
    """거래대금 상위 종목 조회 - KOSPI/KOSDAQ 별도 호출"""
    
    all_stocks = []
    
    # KOSPI 조회
    kospi_stocks = self._get_volume_rank(market_code="1", limit=100)
    all_stocks.extend(kospi_stocks)
    
    # KOSDAQ 조회  
    kosdaq_stocks = self._get_volume_rank(market_code="2", limit=100)
    all_stocks.extend(kosdaq_stocks)
    
    # 거래대금 필터링
    filtered = [s for s in all_stocks if s.trading_value >= min_trading_value]
    
    # 거래대금 순 정렬
    filtered.sort(key=lambda x: x.trading_value, reverse=True)
    
    return filtered[:limit]
```
